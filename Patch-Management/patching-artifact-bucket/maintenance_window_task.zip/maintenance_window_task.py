# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: MIT-0
import boto3
import os
import uuid
from boto3.session import Session

# Initialize AWS service clients
ssm = boto3.client('ssm')
sts = boto3.client('sts')

def lambda_handler(event, context):
    print("=== Patch Automation Lambda Started ===")
    print(f"Received event: {event}")

    # Extract parameters from the event
    patching_tag_key = os.environ.get('CustomPatchingTagKey', 'patchingphase')
    patchingphase = event.get(patching_tag_key, 'DefaultPhase')
    RunPatchBaselineOperation = event.get('patching_operation', 'Install')
    RunPatchBaselineRebootOption = event.get('operation_post_patching', 'RebootIfNeeded')
    RunPatchBaselineInstallOverrideList = event.get('run_patch_baseline_install_override_list', '')

    print(f"Patch Phase: {patchingphase}")
    print(f"Patch Operation: {RunPatchBaselineOperation}")
    print(f"Reboot Option: {RunPatchBaselineRebootOption}")
    print(f"Install Override List: {RunPatchBaselineInstallOverrideList}")

    # Get AWS account ID
    TargetAccountsArray = sts.get_caller_identity()['Account']
    print(f"Target AWS Account: {TargetAccountsArray}")

    # Get regions
    regions = os.environ.get("WORKLOAD_REGIONS", "")
    TargetRegionIdsArray = regions.split(",") if regions else []
    print(f"Target Regions: {TargetRegionIdsArray}")

    # Get environment variables
    ExecutionRoleName = os.environ.get("EXECUTION_ROLE_NAME", "default-execution-role")
    AdministrationRoleName = os.environ.get("ADMINISTRATION_ROLE_NAME", "default-admin-role")
    DocumentName = os.environ.get("DOCUMENT_NAME", "default-document-name")
    ResourceGroupKey = 'tag:maintenance_window'
    
    print(f"Execution Role Name: {ExecutionRoleName}")
    print(f"Administration Role Name: {AdministrationRoleName}")
    print(f"SSM Document Name: {DocumentName}")
    print(f"ResourceGroupKey: {ResourceGroupKey}")
    print(f"ResourceGroupName: {patchingphase}_maintenance_window")

    # Build parameters
    parms = {
        'AutomationAssumeRole': [f'arn:aws:iam::{TargetAccountsArray}:role/{AdministrationRoleName}'],
        'Operation': [f'{RunPatchBaselineOperation}'],
        'RebootOption': [f'{RunPatchBaselineRebootOption}'],
        'SnapshotId': [str(uuid.uuid4())],
        'ResourceGroupKey': [ResourceGroupKey],
        'ResourceGroupName': [f'{patchingphase}_maintenance_window']
    }

    if RunPatchBaselineInstallOverrideList:
        parms['InstallOverrideList'] = [RunPatchBaselineInstallOverrideList]
        print(f"Including InstallOverrideList: {RunPatchBaselineInstallOverrideList}")

    print("Starting SSM Automation execution with parameters:")
    print(parms)

    # Start SSM Automation execution
    try:
        response = ssm.start_automation_execution(
            DocumentName=DocumentName,
            Parameters=parms,
            TargetLocations=[
                {
                    'Accounts': [TargetAccountsArray],
                    'Regions': TargetRegionIdsArray,
                    'TargetLocationMaxConcurrency': '5',
                    'TargetLocationMaxErrors': '13',
                    'ExecutionRoleName': ExecutionRoleName
                }
            ]
        )
        print("SSM Automation Execution started successfully.")
        print(f"SSM Response: {response}")
    except Exception as e:
        print(f"Error occurred while starting automation execution: {str(e)}")
        raise

    return {
        'statusCode': 200,
        'body': response
    }
