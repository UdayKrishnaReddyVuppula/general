import boto3
import json
import os
import random
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
CH = logging.StreamHandler()
CH.setLevel(logging.INFO)
FORMATTER = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
CH.setFormatter(FORMATTER)
logger.addHandler(CH)

class EmergencyPatching(object):

    def __init__(self, event, context):
        try:
            global session
            session = boto3.session.Session()
            self.organizations_client = session.client('organizations')
            self.task_lambda_name = os.environ["TASK_LAMBDA_NAME"]
            self.asg_task_lambda_name = os.environ["ASG_TASK_LAMBDA_NAME"]
            self.patching_template_region = os.environ["PATCHING_TEMPLATE_REGION"]
            self.child_account_role = os.environ["CHILD_ACCOUNT_ROLE"]

            self.taskLambdaPayload = event  # Accept full event as-is
            self.include_asg = event.get('include_asg', 'No')  # Default to 'No' if not provided

            print("Lambda Payload:", self.taskLambdaPayload)
        except Exception as exception:
            print("Unable to initialize EmergencyPatching")
            raise Exception(str(exception))

    def get_accounts(self):
        paginator = self.organizations_client.get_paginator('list_accounts')
        page_iterator = paginator.paginate()
        for page in page_iterator:
            accounts_list = page['Accounts']
            for account in accounts_list:
                try:
                    account_id = account['Id']
                    if account['Status'] == "ACTIVE":
                        self.assume_role(account_id)
                        lambda_client_child = self.assumeRoleSession.client('lambda', region_name=self.patching_template_region)

                        lambda_client_child.invoke(
                            FunctionName=self.task_lambda_name,
                            Payload=json.dumps(self.taskLambdaPayload),
                            InvocationType='Event'
                        )

                        if self.include_asg == 'Yes':
                            lambda_client_child.invoke(
                                FunctionName=self.asg_task_lambda_name,
                                Payload=json.dumps(self.taskLambdaPayload),
                                InvocationType='Event'
                            )
                except Exception as exception:
                    print(f"Exception for account {account_id}: {exception}")

    def assume_role(self, child_account_id):
        secondary_rolearn = f"arn:aws:iam::{child_account_id}:role/{self.child_account_role}"
        secondary_session_name = "SecondarySession-" + str(random.randint(1, 100000))
        sts_client = session.client('sts')

        secondaryRoleCreds = sts_client.assume_role(
            RoleArn=secondary_rolearn,
            RoleSessionName=secondary_session_name
        )
        credentials = secondaryRoleCreds['Credentials']

        self.assumeRoleSession = boto3.session.Session(
            credentials['AccessKeyId'],
            credentials['SecretAccessKey'],
            credentials['SessionToken']
        )
        logger.info(f'Assumed role in child account {child_account_id}')

def lambda_handler(event, context):
    """
    Entry point for the Lambda execution
    """
    emergency_patching = EmergencyPatching(event, context)
    emergency_patching.get_accounts()
